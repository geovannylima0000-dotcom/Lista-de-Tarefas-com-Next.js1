"use client";

import TodoItem from "./TodoItem";

const MENSAGENS_VAZIO = {
  vazia: "Sua lista está vazia. Escreva a primeira tarefa no campo acima.",
  todas: "Nenhuma tarefa por aqui.",
  pendentes: "Tudo em dia! Não há tarefas pendentes.",
  concluidas: "Nenhuma tarefa concluída ainda. Marque uma para vê-la aqui.",
};

// Renderiza as tarefas com map(); mostra uma mensagem quando não há nada para exibir.
export default function TodoList({ tarefas, filtro, total, onToggle, onDelete }) {
  if (tarefas.length === 0) {
    const mensagem = total === 0 ? MENSAGENS_VAZIO.vazia : MENSAGENS_VAZIO[filtro];
    return <p className="empty">{mensagem}</p>;
  }

  return (
    <ul className="list">
      {tarefas.map((tarefa) => (
        <TodoItem key={tarefa.id} tarefa={tarefa} onToggle={onToggle} onDelete={onDelete} />
      ))}
    </ul>
  );
}
