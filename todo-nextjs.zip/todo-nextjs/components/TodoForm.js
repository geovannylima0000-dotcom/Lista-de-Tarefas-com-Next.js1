"use client";

import { useState } from "react";

// Formulário para cadastrar uma nova tarefa.
export default function TodoForm({ onAdd }) {
  const [texto, setTexto] = useState("");

  function handleSubmit(event) {
    event.preventDefault();
    const limpo = texto.trim();
    if (!limpo) return; // ignora tarefas vazias
    onAdd(limpo);
    setTexto("");
  }

  return (
    <form className="form" onSubmit={handleSubmit}>
      <label htmlFor="nova-tarefa" className="sr-only">
        Nova tarefa
      </label>
      <input
        id="nova-tarefa"
        className="form__input"
        type="text"
        value={texto}
        onChange={(event) => setTexto(event.target.value)}
        placeholder="O que precisa ser feito?"
        maxLength={120}
        autoComplete="off"
      />
      <button className="btn btn--primary" type="submit" disabled={!texto.trim()}>
        Adicionar
      </button>
    </form>
  );
}
