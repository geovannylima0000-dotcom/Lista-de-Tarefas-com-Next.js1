"use client";

// Uma tarefa: caixa de seleção para concluir/reabrir e botão para excluir.
export default function TodoItem({ tarefa, onToggle, onDelete }) {
  return (
    <li className={`item${tarefa.concluida ? " is-done" : ""}`}>
      <label className="item__main">
        <input
          className="item__check"
          type="checkbox"
          checked={tarefa.concluida}
          onChange={() => onToggle(tarefa.id)}
        />
        <span className="item__box" aria-hidden="true">
          <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3.5 8.5l3 3 6-7" />
          </svg>
        </span>
        <span className="item__text">{tarefa.texto}</span>
      </label>

      <button
        type="button"
        className="item__delete"
        onClick={() => onDelete(tarefa.id)}
        aria-label={`Excluir tarefa: ${tarefa.texto}`}
      >
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 002 2h6a2 2 0 002-2l1-12M9 7V4h6v3" />
        </svg>
      </button>
    </li>
  );
}
