"use client";

const FILTROS = [
  { valor: "todas", rotulo: "Todas" },
  { valor: "pendentes", rotulo: "Pendentes" },
  { valor: "concluidas", rotulo: "Concluídas" },
];

// Botões para alternar entre todas, pendentes e concluídas.
export default function FilterTabs({ filtroAtual, onChange, contagens }) {
  return (
    <div className="filters" role="group" aria-label="Filtrar tarefas">
      {FILTROS.map((filtro) => {
        const ativo = filtroAtual === filtro.valor;
        return (
          <button
            key={filtro.valor}
            type="button"
            className={`filters__btn${ativo ? " is-active" : ""}`}
            aria-pressed={ativo}
            onClick={() => onChange(filtro.valor)}
          >
            {filtro.rotulo}
            <span className="filters__count">{contagens[filtro.valor]}</span>
          </button>
        );
      })}
    </div>
  );
}
