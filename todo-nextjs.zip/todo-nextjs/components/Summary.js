// Mostra a quantidade de tarefas: pendentes em destaque, total e progresso.
export default function Summary({ total, pendentes, concluidas }) {
  const percentual = total === 0 ? 0 : Math.round((concluidas / total) * 100);

  return (
    <section className="summary" aria-live="polite">
      <p className="summary__main">
        <span className="summary__number">{pendentes}</span>
        <span className="summary__label">
          {pendentes === 1 ? "tarefa pendente" : "tarefas pendentes"}
        </span>
      </p>

      <p className="summary__detail">
        {total === 0
          ? "Nenhuma tarefa cadastrada"
          : `${concluidas} de ${total} ${total === 1 ? "tarefa concluída" : "tarefas concluídas"}`}
      </p>

      <div
        className="progress"
        role="progressbar"
        aria-label="Progresso das tarefas"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={percentual}
      >
        <div className="progress__bar" style={{ width: `${percentual}%` }} />
      </div>
    </section>
  );
}
